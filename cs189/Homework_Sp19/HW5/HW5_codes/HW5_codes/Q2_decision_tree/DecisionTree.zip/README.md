
Just run the whole codes as it is ordered. All the scores are located on the bottom but not right after each training model.

I've also attached .py of the homework but I think running the jupyter notebook file would be better.
